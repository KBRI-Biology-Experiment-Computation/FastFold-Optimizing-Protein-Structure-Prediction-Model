from .options import _set_jit_fusion_options

_set_jit_fusion_options()